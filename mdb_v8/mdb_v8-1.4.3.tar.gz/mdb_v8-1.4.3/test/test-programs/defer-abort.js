setImmediate(function doExplicitAbort() { process.abort(); });
