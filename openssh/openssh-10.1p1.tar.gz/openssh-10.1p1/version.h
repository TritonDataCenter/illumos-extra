/* $OpenBSD: version.h,v 1.106 2025/10/06 01:45:22 djm Exp $ */

#define SSH_VERSION	"OpenSSH_10.1"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
