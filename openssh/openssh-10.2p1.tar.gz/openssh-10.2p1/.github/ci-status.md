master :
[![C/C++ CI](../../../actions/workflows/c-cpp.yml/badge.svg)](../../../actions/workflows/c-cpp.yml?query=branch:master)
[![VM CI](../../../actions/workflows/vm.yml/badge.svg)](../../../actions/workflows/vm.yml?query=branch:master)
[![C/C++ CI self-hosted](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml/badge.svg)](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml?query=branch:master)
[![Upstream self-hosted](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/upstream.yml/badge.svg)](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/upstream.yml?query=branch:master)
[![CIFuzz](../../../actions/workflows/cifuzz.yml/badge.svg)](../../../actions/workflows/cifuzz.yml)
[![Fuzzing Status](https://oss-fuzz-build-logs.storage.googleapis.com/badges/openssh.svg)](https://issues.oss-fuzz.com/issues?q="Project:+openssh"+is:open)
[![Coverity Status](https://scan.coverity.com/projects/21341/badge.svg)](https://scan.coverity.com/projects/openssh-portable)
<br>

10.1 :
[![C/C++ CI](../../../actions/workflows/c-cpp.yml/badge.svg?branch=V_10_1)](../../../actions/workflows/c-cpp.yml?query=branch:V_10_1)
[![VM CI](../../../actions/workflows/vm.yml/badge.svg?branch=V_10_1)](../../../actions/workflows/vm.yml?query=branch:V_10_1)
[![C/C++ CI self-hosted](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml/badge.svg?branch=V_10_1)](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml?query=branch:V_10_1)

10.0 :
[![C/C++ CI](../../../actions/workflows/c-cpp.yml/badge.svg?branch=V_10_0)](../../../actions/workflows/c-cpp.yml?query=branch:V_10_0)
[![C/C++ CI self-hosted](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml/badge.svg?branch=V_10_0)](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml?query=branch:V_10_0)

9.9 :
[![C/C++ CI](../../../actions/workflows/c-cpp.yml/badge.svg?branch=V_9_9)](../../../actions/workflows/c-cpp.yml?query=branch:V_9_9)
[![C/C++ CI self-hosted](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml/badge.svg?branch=V_9_9)](https://github.com/openssh/openssh-portable-selfhosted/actions/workflows/selfhosted.yml?query=branch:V_9_9)
