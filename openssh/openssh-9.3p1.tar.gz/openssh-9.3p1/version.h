/* $OpenBSD: version.h,v 1.97 2023/03/15 21:19:57 djm Exp $ */

#define SSH_VERSION	"OpenSSH_9.3"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
