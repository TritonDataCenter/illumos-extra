echo "\$OMFileAsyncWriting on" > rsyslog.action.1.include
source $srcdir/dynfile_cachemiss.sh
