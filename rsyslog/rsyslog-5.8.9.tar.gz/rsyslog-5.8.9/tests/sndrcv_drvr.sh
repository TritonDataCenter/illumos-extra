source $srcdir/sndrcv_drvr_noexit.sh $1 $2
source $srcdir/diag.sh exit
