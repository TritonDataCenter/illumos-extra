rsRetVal solaris_readLog(int fd);
void imsolaris_logerror(int err, char *errStr);
