/*
 * Extended Attribute support for rsync.
 * Written by Jay Fenlason, vaguely based on the ACLs patch.
 *
 * Copyright (C) 2004 Red Hat, Inc.
 * Copyright (C) 2006-2022 Wayne Davison
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, visit the http://fsf.org website.
 */

#include "rsync.h"
#include "ifuncs.h"
#include "inums.h"
#include "lib/sysxattrs.h"

#ifdef SUPPORT_XATTRS

extern int dry_run;
extern int am_root;
extern int am_sender;
extern int am_generator;
extern int read_only;
extern int list_only;
extern int preserve_xattrs;
extern int preserve_links;
extern int preserve_devices;
extern int preserve_specials;
extern int checksum_seed;
extern int saw_xattr_filter;

extern struct name_num_item *xattr_sum_nni;
extern int xattr_sum_len;

#define RSYNC_XAL_INITIAL 5
#define RSYNC_XAL_LIST_INITIAL 100

#define MAX_XATTR_DIGEST_LEN MD5_DIGEST_LEN
#define MAX_FULL_DATUM 32
#define MAX_XATTR_LIST_BYTES ((size_t)512 * 1024 * 1024)
#define MAX_XATTR_VALUE_BYTES ((size_t)128 * 1024 * 1024)

#define HAS_PREFIX(str, prfx) (*(str) == *(prfx) && strncmp(str, prfx, sizeof (prfx) - 1) == 0)

#define XATTR_ABBREV(x) ((size_t)((x).name - (x).datum) < (x).datum_len)

#define XSTATE_ABBREV	1
#define XSTATE_DONE	2
#define XSTATE_TODO	3

#define USER_PREFIX "user."
#define UPRE_LEN ((int)sizeof USER_PREFIX - 1)
#define SYSTEM_PREFIX "system."
#define SPRE_LEN ((int)sizeof SYSTEM_PREFIX - 1)

#ifdef HAVE_LINUX_XATTRS
#define MIGHT_NEED_RPRE (am_root <= 0)
#define RSYNC_PREFIX USER_PREFIX "rsync."
#else
#define MIGHT_NEED_RPRE am_root
#define RSYNC_PREFIX "rsync."
#endif
#define RPRE_LEN ((int)sizeof RSYNC_PREFIX - 1)

#define XSTAT_SUFFIX "stat"
#define XSTAT_ATTR RSYNC_PREFIX "%" XSTAT_SUFFIX
#define XACC_ACL_SUFFIX "aacl"
#define XACC_ACL_ATTR RSYNC_PREFIX "%" XACC_ACL_SUFFIX
#define XDEF_ACL_SUFFIX "dacl"
#define XDEF_ACL_ATTR RSYNC_PREFIX "%" XDEF_ACL_SUFFIX

typedef struct {
	char *datum, *name;
	size_t datum_len, name_len;
	int num;
} rsync_xa;

struct _rsync_xa_list;

typedef struct _rsync_xa_list_ref {
	struct _rsync_xa_list_ref *next;
	int ndx;
} rsync_xa_list_ref;

typedef struct _rsync_xa_list {
	int ndx;
	int64 key;
	item_list xa_items;
} rsync_xa_list;

static size_t namebuf_len = 0;
static char *namebuf = NULL;

static const rsync_xa_list empty_xa_list = {
	.xa_items = EMPTY_ITEM_LIST,
};
static const item_list empty_xattr = EMPTY_ITEM_LIST;
static item_list rsync_xal_l = EMPTY_ITEM_LIST;
static struct hashtable *rsync_xal_h = NULL;

static size_t prior_xattr_count = (size_t)-1;

/* ------------------------------------------------------------------------- */

static void rsync_xal_free(item_list *xalp)
{
	size_t i;
	rsync_xa *rxas = xalp->items;

	if (!xalp->malloced)
		return;

	for (i = 0; i < xalp->count; i++) {
		free(rxas[i].datum);
		/*free(rxas[i].name);*/
	}
	free(xalp->items);
}

void free_xattr(stat_x *sxp)
{
	if (!sxp->xattr)
		return;
	rsync_xal_free(sxp->xattr);
	free(sxp->xattr);
	sxp->xattr = NULL;
}

static int rsync_xal_compare_names(const void *x1, const void *x2)
{
	const rsync_xa *xa1 = x1;
	const rsync_xa *xa2 = x2;
	return strcmp(xa1->name, xa2->name);
}

/* List the names of fname's xattrs into the global namebuf.  When fd >= 0 the
 * list is read from that held fd (sys_flistxattr) so a parent-symlink race
 * can't redirect it; otherwise it falls back to the path (sys_llistxattr). */
static ssize_t get_xattr_names(const char *fname, int fd)
{
	ssize_t list_len;
	int64 arg;

	if (!namebuf) {
		namebuf_len = 1024;
		namebuf = new_array(char, namebuf_len);
	}

	while (1) {
		/* The length returned includes all the '\0' terminators. */
		list_len = fd >= 0 ? sys_flistxattr(fd, namebuf, namebuf_len)
				   : sys_llistxattr(fname, namebuf, namebuf_len);
		if (list_len >= 0) {
			if ((size_t)list_len <= namebuf_len)
				break;
		} else if (errno == ENOTSUP)
			return 0;
		else if (errno != ERANGE) {
			arg = namebuf_len;
		  got_error:
			rsyserr(FERROR_XFER, errno,
				"get_xattr_names: llistxattr(%s,%s) failed",
				full_fname(fname), big_num(arg));
			return -1;
		}
		list_len = fd >= 0 ? sys_flistxattr(fd, NULL, 0)
				   : sys_llistxattr(fname, NULL, 0);
		if (list_len < 0) {
			arg = 0;
			goto got_error;
		}
		if (namebuf_len)
			free(namebuf);
		namebuf_len = list_len + 1024;
		namebuf = new_array(char, namebuf_len);
	}

	return list_len;
}

/* On entry, the *len_ptr parameter contains the size of the extra space we
 * should allocate when we create a buffer for the data.  On exit, it contains
 * the length of the datum. */
/* Read xattr `name`'s value.  When fd >= 0 the read goes through that held fd
 * (sys_fgetxattr) so a parent-symlink race can't redirect it; otherwise it falls
 * back to the path (sys_lgetxattr), matching get_xattr_names(). */
static char *get_xattr_data(const char *fname, int fd, const char *name, size_t *len_ptr, int no_missing_error)
{
	size_t datum_len = fd >= 0 ? sys_fgetxattr(fd, name, NULL, 0)
				   : sys_lgetxattr(fname, name, NULL, 0);
	size_t extra_len = *len_ptr;
	char *ptr;

	*len_ptr = datum_len;

	if (datum_len == (size_t)-1) {
		if (errno == ENOTSUP || no_missing_error)
			return NULL;
		rsyserr(FERROR_XFER, errno,
			"get_xattr_data: lgetxattr(%s,\"%s\",0) failed",
			full_fname(fname), name);
		return NULL;
	}

	if (!datum_len && !extra_len)
		extra_len = 1; /* request non-zero amount of memory */
	if (SIZE_MAX - datum_len < extra_len)
		overflow_exit("get_xattr_data");
	ptr = new_array(char, datum_len + extra_len);

	if (datum_len) {
		size_t len = fd >= 0 ? sys_fgetxattr(fd, name, ptr, datum_len)
				     : sys_lgetxattr(fname, name, ptr, datum_len);
		if (len != datum_len) {
			if (len == (size_t)-1) {
				rsyserr(FERROR_XFER, errno,
					"get_xattr_data: lgetxattr(%s,\"%s\",%ld) failed",
					full_fname(fname), name, (long)datum_len);
			} else {
				rprintf(FERROR_XFER,
					"get_xattr_data: lgetxattr(%s,\"%s\",%ld) returned %ld\n",
					full_fname(fname), name,
					(long)datum_len, (long)len);
			}
			free(ptr);
			return NULL;
		}
	}

	return ptr;
}

static int rsync_xal_get(const char *fname, int fd, item_list *xalp)
{
	ssize_t list_len, name_len;
	size_t datum_len, name_offset;
	char *name, *ptr;
#ifdef HAVE_LINUX_XATTRS
	int user_only = am_sender ? 0 : !am_root;
#endif
	rsync_xa *rxa;
	int count;

	/* This puts the name list into the "namebuf" buffer. */
	if ((list_len = get_xattr_names(fname, fd)) < 0)
		return -1;

	for (name = namebuf; list_len > 0; name += name_len) {
		name_len = strlen(name) + 1;
		list_len -= name_len;

		if (saw_xattr_filter) {
			if (name_is_excluded(name, NAME_IS_XATTR, ALL_FILTERS))
				continue;
		}
#ifdef HAVE_LINUX_XATTRS
		/* Choose between ignoring the system namespace or (non-root) ignoring any non-user namespace. */
		else if (user_only ? !HAS_PREFIX(name, USER_PREFIX) : HAS_PREFIX(name, SYSTEM_PREFIX))
			continue;
#endif

		/* No rsync.%FOO attributes are copied w/o 2 -X options. */
		if (name_len > RPRE_LEN && name[RPRE_LEN] == '%' && HAS_PREFIX(name, RSYNC_PREFIX)) {
			if ((am_sender && preserve_xattrs < 2)
			 || (am_root < 0
			  && (strcmp(name+RPRE_LEN+1, XSTAT_SUFFIX) == 0
			   || strcmp(name+RPRE_LEN+1, XACC_ACL_SUFFIX) == 0
			   || strcmp(name+RPRE_LEN+1, XDEF_ACL_SUFFIX) == 0)))
				continue;
		}

		datum_len = name_len; /* Pass extra size to get_xattr_data() */
		if (!(ptr = get_xattr_data(fname, fd, name, &datum_len, 0)))
			return -1;

		if (datum_len > MAX_FULL_DATUM) {
			/* For large datums, we store a flag and a checksum. */
			name_offset = 1 + MAX_XATTR_DIGEST_LEN;
			sum_init(xattr_sum_nni, checksum_seed);
			sum_update(ptr, datum_len);
			free(ptr);

			ptr = new_array(char, name_offset + name_len);
			*ptr = XSTATE_ABBREV;
			sum_end(ptr + 1);
		} else
			name_offset = datum_len;

		rxa = EXPAND_ITEM_LIST(xalp, rsync_xa, RSYNC_XAL_INITIAL);
		rxa->name = ptr + name_offset;
		memcpy(rxa->name, name, name_len);
		rxa->datum = ptr;
		rxa->name_len = name_len;
		rxa->datum_len = datum_len;
	}
	count = xalp->count;
	rxa = xalp->items;
	if (count > 1)
		qsort(rxa, count, sizeof (rsync_xa), rsync_xal_compare_names);
	/* Guard count==0: rxa is then xalp->items (possibly NULL) and the
	 * "rxa += count-1" init would form NULL-1 (undefined). */
	if (count) {
		for (rxa += count-1; count; count--, rxa--)
			rxa->num = count;
	}
	return 0;
}

/* Read the xattr(s) for this filename. */
/* Collect fname's xattrs into sxp.  fd >= 0 reads them through that held fd
 * (race-safe); fd < 0 uses the path. */
int get_xattr(const char *fname, int fd, stat_x *sxp)
{
	sxp->xattr = new(item_list);
	*sxp->xattr = empty_xattr;

	if (S_ISREG(sxp->st.st_mode) || S_ISDIR(sxp->st.st_mode)) {
		/* Everyone supports this. */
	} else if (S_ISLNK(sxp->st.st_mode)) {
#ifndef NO_SYMLINK_XATTRS
		if (!preserve_links)
#endif
			return 0;
	} else if (IS_SPECIAL(sxp->st.st_mode)) {
#ifndef NO_SPECIAL_XATTRS
		if (!preserve_specials)
#endif
			return 0;
	} else if (IS_DEVICE(sxp->st.st_mode)) {
#ifndef NO_DEVICE_XATTRS
		if (!preserve_devices)
#endif
			return 0;
	} else if (IS_MISSING_FILE(sxp->st))
		return 0;

	if (rsync_xal_get(fname, fd, sxp->xattr) < 0) {
		free_xattr(sxp);
		return -1;
	}
	return 0;
}

/* Copy xattrs from source to dest.  source_fd/dest_fd, when >= 0, are held
 * O_NOFOLLOW-opened fds so the source read (fgetxattr) and the dest set
 * (fsetxattr) can't be redirected by a parent-symlink race; a < 0 fd keeps the
 * path-based l-variant (non-hardened receivers, or no held fd available). */
int copy_xattrs(const char *source, int source_fd, const char *dest, int dest_fd)
{
	ssize_t list_len, name_len;
	size_t datum_len;
	char *name, *ptr;
#ifdef HAVE_LINUX_XATTRS
	int user_only = am_sender ? 0 : am_root <= 0;
#endif

	/* This puts the name list into the "namebuf" buffer. */
	if ((list_len = get_xattr_names(source, source_fd)) < 0)
		return -1;

	for (name = namebuf; list_len > 0; name += name_len) {
		name_len = strlen(name) + 1;
		list_len -= name_len;

		if (saw_xattr_filter) {
			if (name_is_excluded(name, NAME_IS_XATTR, ALL_FILTERS))
				continue;
		}
#ifdef HAVE_LINUX_XATTRS
		/* Choose between ignoring the system namespace or (non-root) ignoring any non-user namespace. */
		else if (user_only ? !HAS_PREFIX(name, USER_PREFIX) : HAS_PREFIX(name, SYSTEM_PREFIX))
			continue;
#endif

		datum_len = 0;
		if (!(ptr = get_xattr_data(source, source_fd, name, &datum_len, 0)))
			return -1;
		if ((dest_fd >= 0 ? sys_fsetxattr(dest_fd, name, ptr, datum_len)
				  : sys_lsetxattr(dest, name, ptr, datum_len)) < 0) {
			int save_errno = errno ? errno : EINVAL;
			rsyserr(FERROR_XFER, errno,
				"copy_xattrs: %ssetxattr(%s,\"%s\") failed",
				dest_fd >= 0 ? "f" : "l", full_fname(dest), name);
			errno = save_errno;
			free(ptr);
			return -1;
		}
		free(ptr);
	}

	return 0;
}

static int64 xattr_lookup_hash(const item_list *xalp)
{
	const rsync_xa *rxas = xalp->items;
	size_t i;
	/* Accumulate unsigned: the summed hash values routinely overflow a
	 * signed int64 (UB), and we only care about the resulting bit pattern. */
	uint64_t key = (uint64_t)hashlittle2(&xalp->count, sizeof xalp->count);

	for (i = 0; i < xalp->count; i++) {
		key += (uint64_t)hashlittle2(rxas[i].name, rxas[i].name_len);
		if (rxas[i].datum_len > MAX_FULL_DATUM)
			key += (uint64_t)hashlittle2(rxas[i].datum, xattr_sum_len);
		else
			key += (uint64_t)hashlittle2(rxas[i].datum, rxas[i].datum_len);
	}

	return (int64)key;
}

static int find_matching_xattr(const item_list *xalp)
{
	const struct ht_int64_node *node;
	const rsync_xa_list_ref *ref;
	int64 key;

	if (rsync_xal_h == NULL)
		return -1;

	key = xattr_lookup_hash(xalp);

	node = hashtable_find(rsync_xal_h, key, NULL);
	if (node == NULL)
		return -1;

	if (node->data == NULL)
		return -1;

	for (ref = node->data; ref != NULL; ref = ref->next) {
		const rsync_xa_list *ptr = rsync_xal_l.items;
		const rsync_xa *rxas1;
		const rsync_xa *rxas2 = xalp->items;
		size_t j;

		ptr += ref->ndx;
		rxas1 = ptr->xa_items.items;

		/* Wrong number of elements? */
		if (ptr->xa_items.count != xalp->count)
			continue;
		/* any elements different? */
		for (j = 0; j < xalp->count; j++) {
			if (rxas1[j].name_len != rxas2[j].name_len
			 || rxas1[j].datum_len != rxas2[j].datum_len
			 || strcmp(rxas1[j].name, rxas2[j].name))
				break;
			if (rxas1[j].datum_len > MAX_FULL_DATUM) {
				if (memcmp(rxas1[j].datum + 1,
					   rxas2[j].datum + 1,
					   xattr_sum_len) != 0)
					break;
			} else {
				if (memcmp(rxas1[j].datum, rxas2[j].datum,
					   rxas2[j].datum_len))
					break;
			}
		}
		/* no differences found.  This is The One! */
		if (j == xalp->count)
			return ref->ndx;
	}

	return -1;
}

/* Store *xalp on the end of rsync_xal_l */
static int rsync_xal_store(item_list *xalp)
{
	struct ht_int64_node *node;
	int ndx = rsync_xal_l.count; /* pre-incremented count */
	rsync_xa_list *new_list = EXPAND_ITEM_LIST(&rsync_xal_l, rsync_xa_list, RSYNC_XAL_LIST_INITIAL);
	rsync_xa_list_ref *new_ref;
	/* Since the following call starts a new list, we know it will hold the
	 * entire initial-count, not just enough space for one new item. */
	*new_list = empty_xa_list;
	(void)EXPAND_ITEM_LIST(&new_list->xa_items, rsync_xa, xalp->count);
	/* xalp->items is NULL for an empty list; memcpy(dst, NULL, 0) is UB. */
	if (xalp->count)
		memcpy(new_list->xa_items.items, xalp->items, xalp->count * sizeof (rsync_xa));
	new_list->xa_items.count = xalp->count;
	xalp->count = 0;

	new_list->ndx = ndx;
	new_list->key = xattr_lookup_hash(&new_list->xa_items);

	if (rsync_xal_h == NULL)
		rsync_xal_h = hashtable_create(512, HT_KEY64);

	new_ref = new0(rsync_xa_list_ref);
	new_ref->ndx = ndx;

	node = hashtable_find(rsync_xal_h, new_list->key, new_ref);
	if (node->data != (void*)new_ref) {
		rsync_xa_list_ref *ref = node->data;

		while (ref != NULL) {
			if (ref->next != NULL) {
				ref = ref->next;
				continue;
			}

			ref->next = new_ref;
			break;
		}
	}

	return ndx;
}

/* Send the make_xattr()-generated xattr list for this flist entry. */
int send_xattr(int f, stat_x *sxp)
{
	int ndx = find_matching_xattr(sxp->xattr);

	/* Send 0 (-1 + 1) to indicate that literal xattr data follows. */
	write_varint(f, ndx + 1);

	if (ndx < 0) {
		rsync_xa *rxa;
		int count = sxp->xattr->count;
		write_varint(f, count);
		for (rxa = sxp->xattr->items; count--; rxa++) {
			size_t name_len = rxa->name_len;
			const char *name = rxa->name;
			/* Strip the rsync prefix from disguised namespaces. */
			if (name_len > RPRE_LEN
#ifdef HAVE_LINUX_XATTRS
			 && am_root < 0
#endif
			 && name[RPRE_LEN] != '%' && HAS_PREFIX(name, RSYNC_PREFIX)) {
				name += RPRE_LEN;
				name_len -= RPRE_LEN;
			}
#ifndef HAVE_LINUX_XATTRS
			else {
				/* Put everything else in the user namespace. */
				name_len += UPRE_LEN;
			}
#endif
			write_varint(f, name_len);
			write_varint(f, rxa->datum_len);
#ifndef HAVE_LINUX_XATTRS
			if (name_len > rxa->name_len) {
				write_buf(f, USER_PREFIX, UPRE_LEN);
				name_len -= UPRE_LEN;
			}
#endif
			write_buf(f, name, name_len);
			if (rxa->datum_len > MAX_FULL_DATUM)
				write_buf(f, rxa->datum + 1, xattr_sum_len);
			else
				write_bigbuf(f, rxa->datum, rxa->datum_len);
		}
		ndx = rsync_xal_store(sxp->xattr); /* adds item to rsync_xal_l */
	}

	return ndx;
}

/* Return a flag indicating if we need to change a file's xattrs.  If
 * "find_all" is specified, also mark any abbreviated xattrs that we
 * need so that send_xattr_request() can tell the sender about them. */
int xattr_diff(struct file_struct *file, stat_x *sxp, int find_all)
{
	const rsync_xa_list *glst = rsync_xal_l.items;
	const item_list *lst;
	rsync_xa *snd_rxa, *rec_rxa;
	int snd_cnt, rec_cnt;
	int cmp, same, xattrs_equal = 1;

	if (sxp && XATTR_READY(*sxp)) {
		rec_rxa = sxp->xattr->items;
		rec_cnt = sxp->xattr->count;
	} else {
		rec_rxa = NULL;
		rec_cnt = 0;
	}

	if (F_XATTR(file) >= 0) {
		glst += F_XATTR(file);
		lst = &glst->xa_items;
	} else
		lst = &empty_xattr;

	snd_rxa = lst->items;
	snd_cnt = lst->count;

	/* If the count of the sender's xattrs is different from our
	 * (receiver's) xattrs, the lists are not the same. */
	if (snd_cnt != rec_cnt) {
		if (!find_all)
			return 1;
		xattrs_equal = 0;
	}

	while (snd_cnt) {
		cmp = rec_cnt ? strcmp(snd_rxa->name, rec_rxa->name) : -1;
		if (cmp > 0)
			same = 0;
		else if (snd_rxa->datum_len > MAX_FULL_DATUM) {
			same = cmp == 0 && snd_rxa->datum_len == rec_rxa->datum_len
			    && memcmp(snd_rxa->datum + 1, rec_rxa->datum + 1,
				      xattr_sum_len) == 0;
			/* Flag unrequested items that we need. */
			if (!same && find_all && snd_rxa->datum[0] == XSTATE_ABBREV)
				snd_rxa->datum[0] = XSTATE_TODO;
		} else {
			same = cmp == 0 && snd_rxa->datum_len == rec_rxa->datum_len
			    && memcmp(snd_rxa->datum, rec_rxa->datum,
				      snd_rxa->datum_len) == 0;
		}
		if (!same) {
			if (!find_all)
				return 1;
			xattrs_equal = 0;
		}

		if (cmp <= 0) {
			snd_rxa++;
			snd_cnt--;
		}
		if (cmp >= 0) {
			rec_rxa++;
			rec_cnt--;
		}
	}

	if (rec_cnt)
		xattrs_equal = 0;

	return !xattrs_equal;
}

/* When called by the generator (with a NULL fname), this tells the sender
 * all the abbreviated xattr values we need.  When called by the sender
 * (with a non-NULL fname), we send all the extra xattr data it needs.
 * The generator may also call with f_out < 0 to just change all the
 * XSTATE_ABBREV states into XSTATE_DONE. */
void send_xattr_request(const char *fname, struct file_struct *file, int f_out)
{
	const rsync_xa_list *glst = rsync_xal_l.items;
	const item_list *lst;
	int cnt, prior_req = 0;
	rsync_xa *rxa;

	glst += F_XATTR(file);
	lst = &glst->xa_items;

	for (rxa = lst->items, cnt = lst->count; cnt--; rxa++) {
		if (rxa->datum_len <= MAX_FULL_DATUM)
			continue;
		switch (rxa->datum[0]) {
		case XSTATE_ABBREV:
			/* Items left abbreviated matched the sender's checksum, so
			 * the receiver will cache the local data for future use. */
			if (am_generator)
				rxa->datum[0] = XSTATE_DONE;
			continue;
		case XSTATE_TODO:
			assert(f_out >= 0);
			break;
		default:
			continue;
		}

		/* Flag that we handled this abbreviated item. */
		rxa->datum[0] = XSTATE_DONE;

		write_varint(f_out, rxa->num - prior_req);
		prior_req = rxa->num;

		if (fname) {
			size_t len = 0;
			char *ptr;

			/* Re-read the long datum. */
			if (!(ptr = get_xattr_data(fname, -1, rxa->name, &len, 0))) {
				rprintf(FERROR_XFER, "failed to re-read xattr %s for %s\n", rxa->name, fname);
				write_varint(f_out, 0);
				continue;
			}

			write_varint(f_out, len); /* length might have changed! */
			write_bigbuf(f_out, ptr, len);
			free(ptr);
		}
	}

	if (f_out >= 0)
		write_byte(f_out, 0); /* end the list */
}

/* When called by the sender, read the request from the generator and mark
 * any needed xattrs with a flag that lets us know they need to be sent to
 * the receiver.  When called by the receiver, reads the sent data and
 * stores it in place of its checksum. */
int recv_xattr_request(struct file_struct *file, int f_in)
{
	const rsync_xa_list *glst = rsync_xal_l.items;
	const item_list *lst;
	char *old_datum, *name;
	rsync_xa *rxa;
	int rel_pos, cnt, num, got_xattr_data = 0;

	if (F_XATTR(file) < 0) {
		rprintf(FERROR, "recv_xattr_request: internal data error!\n");
		exit_cleanup(RERR_PROTOCOL);
	}
	glst += F_XATTR(file);
	lst = &glst->xa_items;

	cnt = lst->count;
	rxa = lst->items;
	num = 0;
	while ((rel_pos = read_varint(f_in)) != 0) {
		/* Detect signed overflow before the accumulating add. A hostile
		 * peer could otherwise wrap 'num' to land on an arbitrary value. */
		if ((rel_pos > 0 && num > INT_MAX - rel_pos)
		 || (rel_pos < 0 && num < INT_MIN - rel_pos)) {
			rprintf(FERROR, "xattr rel_pos accumulation overflow [%s]\n", who_am_i());
			exit_cleanup(RERR_PROTOCOL);
		}
		num += rel_pos;
		if (am_sender) {
			/* The sender-related num values are only in order on the sender.
			 * We use that order here to scan forward or backward as needed. */
			if (rel_pos < 0) {
				while (cnt < (int)lst->count && rxa->num > num) {
					rxa--;
					cnt++;
				}
			} else {
				while (cnt > 1 && rxa->num < num) {
					rxa++;
					cnt--;
				}
			}
		} else {
			int j;
			/* The receiving side has no known num order, so we just scan
			 * forward (w/wrap) and hope that the next value is near by. */
			for (j = lst->count; j > 1 && rxa->num != num; j--) {
				if (--cnt)
					rxa++;
				else {
					cnt = lst->count;
					rxa = lst->items;
				}
			}
		}
		if (!cnt || rxa->num != num) {
			rprintf(FERROR, "[%s] could not find xattr #%d for %s\n",
				who_am_i(), num, f_name(file, NULL));
			exit_cleanup(RERR_PROTOCOL);
		}
		if (!XATTR_ABBREV(*rxa) || rxa->datum[0] != XSTATE_ABBREV) {
			rprintf(FERROR, "[%s] internal abbrev error on %s (%s, len=%ld)!\n",
				who_am_i(), f_name(file, NULL), rxa->name, (long)rxa->datum_len);
			exit_cleanup(RERR_PROTOCOL);
		}

		if (am_sender) {
			rxa->datum[0] = XSTATE_TODO;
			continue;
		}

		old_datum = rxa->datum;
		rxa->datum_len = read_varint_size(f_in, MAX_WIRE_XATTR_DATALEN, "xattr datum_len");
		if (rxa->datum_len > MAX_XATTR_VALUE_BYTES) {
			rprintf(FERROR, "xattr datum_len exceeds per-value limit [%s]\n", who_am_i());
			exit_cleanup(RERR_PROTOCOL);
		}

		if (SIZE_MAX - rxa->name_len < rxa->datum_len)
			overflow_exit("recv_xattr_request");
		rxa->datum = new_array(char, rxa->datum_len + rxa->name_len);
		name = rxa->datum + rxa->datum_len;
		memcpy(name, rxa->name, rxa->name_len);
		rxa->name = name;
		free(old_datum);
		read_buf(f_in, rxa->datum, rxa->datum_len);
		got_xattr_data = 1;
	}

	return got_xattr_data;
}

/* ------------------------------------------------------------------------- */

/* receive and build the rsync_xattr_lists */
void receive_xattr(int f, struct file_struct *file)
{
	static item_list temp_xattr = EMPTY_ITEM_LIST;
	int count, num;
#ifdef HAVE_LINUX_XATTRS
	int need_sort = 0;
#else
	int need_sort = 1;
#endif
	int ndx = read_varint(f);
	size_t total_xattr_bytes = 0;

	if (ndx < 0 || (size_t)ndx > rsync_xal_l.count) {
		rprintf(FERROR, "receive_xattr: xa index %d out of"
			" range for %s\n", ndx, f_name(file, NULL));
		exit_cleanup(RERR_STREAMIO);
	}

	if (ndx != 0) {
		F_XATTR(file) = ndx - 1;
		return;
	}

	count = read_varint_bounded(f, 0, MAX_WIRE_XATTR_COUNT, "xattr count");
	if (count != 0) {
		(void)EXPAND_ITEM_LIST(&temp_xattr, rsync_xa, count);
		temp_xattr.count = 0;
	}

	for (num = 1; num <= count; num++) {
		char *ptr, *name;
		rsync_xa *rxa;
		size_t name_len = read_varint_size(f, MAX_WIRE_XATTR_NAMELEN, "xattr name_len");
		size_t datum_len = read_varint_size(f, MAX_WIRE_XATTR_DATALEN, "xattr datum_len");
		size_t dget_len = datum_len > MAX_FULL_DATUM ? 1 + (size_t)xattr_sum_len : datum_len;
		size_t extra_len = MIGHT_NEED_RPRE ? RPRE_LEN : 0;
		if (datum_len > MAX_XATTR_VALUE_BYTES) {
			rprintf(FERROR, "xattr datum_len exceeds per-value limit [%s]\n", who_am_i());
			exit_cleanup(RERR_PROTOCOL);
		}
		if (SIZE_MAX - total_xattr_bytes < name_len
		 || SIZE_MAX - total_xattr_bytes - name_len < datum_len) {
			overflow_exit("receive_xattr");
		}
		total_xattr_bytes += name_len + datum_len;
		if (total_xattr_bytes > MAX_XATTR_LIST_BYTES) {
			rprintf(FERROR, "xattr list exceeds per-file limit [%s]\n", who_am_i());
			exit_cleanup(RERR_PROTOCOL);
		}
		if (SIZE_MAX - dget_len < extra_len || SIZE_MAX - dget_len - extra_len < name_len)
			overflow_exit("receive_xattr");
		ptr = new_array(char, dget_len + extra_len + name_len);
		name = ptr + dget_len + extra_len;
		read_buf(f, name, name_len);
		if (name_len < 1 || name[name_len-1] != '\0') {
			rprintf(FERROR, "Invalid xattr name received (missing trailing \\0).\n");
			exit_cleanup(RERR_FILEIO);
		}
		if (dget_len == datum_len)
			read_buf(f, ptr, dget_len);
		else {
			*ptr = XSTATE_ABBREV;
			read_buf(f, ptr + 1, xattr_sum_len);
		}

		if (saw_xattr_filter) {
			if (name_is_excluded(name, NAME_IS_XATTR, ALL_FILTERS)) {
				free(ptr);
				continue;
			}
		}
#ifdef HAVE_LINUX_XATTRS
		/* Non-root can only save the user namespace. */
		if (am_root <= 0 && !HAS_PREFIX(name, USER_PREFIX)) {
			if (!am_root && !saw_xattr_filter) {
				free(ptr);
				continue;
			}
			name -= RPRE_LEN;
			name_len += RPRE_LEN;
			memcpy(name, RSYNC_PREFIX, RPRE_LEN);
			need_sort = 1;
		}
#else
		/* This OS only has a user namespace, so we either
		 * strip the user prefix, or we put a non-user
		 * namespace inside our rsync hierarchy. */
		if (HAS_PREFIX(name, USER_PREFIX)) {
			name += UPRE_LEN;
			name_len -= UPRE_LEN;
		} else if (am_root) {
			name -= RPRE_LEN;
			name_len += RPRE_LEN;
			memcpy(name, RSYNC_PREFIX, RPRE_LEN);
		} else {
			free(ptr);
			continue;
		}
#endif
		/* No rsync.%FOO attributes are copied w/o 2 -X options. */
		if (preserve_xattrs < 2 && name_len > RPRE_LEN
		 && name[RPRE_LEN] == '%' && HAS_PREFIX(name, RSYNC_PREFIX)) {
			free(ptr);
			continue;
		}

		rxa = EXPAND_ITEM_LIST(&temp_xattr, rsync_xa, 1);
		rxa->name = name;
		rxa->datum = ptr;
		rxa->name_len = name_len;
		rxa->datum_len = datum_len;
		rxa->num = num;
	}

	if (need_sort && temp_xattr.count > 1)
		qsort(temp_xattr.items, temp_xattr.count, sizeof (rsync_xa), rsync_xal_compare_names);

	ndx = rsync_xal_store(&temp_xattr); /* adds item to rsync_xal_l */

	F_XATTR(file) = ndx;
}

/* Turn the xattr data in stat_x into cached xattr data, setting the index
 * values in the file struct. */
void cache_tmp_xattr(struct file_struct *file, stat_x *sxp)
{
	int ndx;

	if (!sxp->xattr)
		return;

	if (prior_xattr_count == (size_t)-1)
		prior_xattr_count = rsync_xal_l.count;
	ndx = find_matching_xattr(sxp->xattr);
	if (ndx < 0)
		ndx = rsync_xal_store(sxp->xattr); /* adds item to rsync_xal_l */

	F_XATTR(file) = ndx;
}

void uncache_tmp_xattrs(void)
{
	if (prior_xattr_count != (size_t)-1) {
		rsync_xa_list *xa_list_item = rsync_xal_l.items;
		rsync_xa_list *xa_list_start = xa_list_item + prior_xattr_count;
		xa_list_item += rsync_xal_l.count;
		rsync_xal_l.count = prior_xattr_count;
		while (xa_list_item-- > xa_list_start) {
			struct ht_int64_node *node;
			rsync_xa_list_ref *ref;

			rsync_xal_free(&xa_list_item->xa_items);

			if (rsync_xal_h == NULL)
				continue;

			node = hashtable_find(rsync_xal_h, xa_list_item->key, NULL);
			if (node == NULL)
				continue;

			if (node->data == NULL)
				continue;

			ref = node->data;
			if (xa_list_item->ndx == ref->ndx) {
				/* xa_list_item is the first in the list. */
				node->data = ref->next;
				free(ref);
				continue;
			}

			while (1) {
				rsync_xa_list_ref *next = ref->next;
				if (next == NULL)
					break;
				if (xa_list_item->ndx == next->ndx) {
					ref->next = next->next;
					free(next);
					break;
				}
				ref = next;
			}
		}
		prior_xattr_count = (size_t)-1;
	}
}

/* Apply the wanted xattr set to fname.  When fd >= 0, the list/set/remove ops
 * that target fname go through that held fd (sys_f*xattr) so a parent-symlink
 * race can't redirect them; the abbreviated-value compare still reads the basis
 * via the fnamecmp path.  fd < 0 keeps the path-based behavior. */
static int rsync_xal_set(const char *fname, item_list *xalp,
			 const char *fnamecmp, stat_x *sxp, int fd)
{
	rsync_xa *rxas = xalp->items;
	ssize_t list_len;
	size_t i, len;
	char *name, *ptr, sum[MAX_XATTR_DIGEST_LEN];
#ifdef HAVE_LINUX_XATTRS
	int user_only = am_root <= 0;
#endif
	size_t name_len;
	int ret = 0;

	/* This puts the current name list into the "namebuf" buffer. */
	if ((list_len = get_xattr_names(fname, fd)) < 0)
		return -1;

	for (i = 0; i < xalp->count; i++) {
		name = rxas[i].name;

		if (XATTR_ABBREV(rxas[i])) {
			/* See if the fnamecmp version is identical. */
			len = name_len = rxas[i].name_len;
			if ((ptr = get_xattr_data(fnamecmp, -1, name, &len, 1)) == NULL) {
			  still_abbrev:
				if (am_generator)
					continue;
				rprintf(FERROR, "Missing abbreviated xattr value, %s, for %s\n",
					rxas[i].name, full_fname(fname));
				ret = -1;
				continue;
			}
			if (len != rxas[i].datum_len) {
				free(ptr);
				goto still_abbrev;
			}

			sum_init(xattr_sum_nni, checksum_seed);
			sum_update(ptr, len);
			sum_end(sum);
			if (memcmp(sum, rxas[i].datum + 1, xattr_sum_len) != 0) {
				free(ptr);
				goto still_abbrev;
			}

			if (fname == fnamecmp)
				; /* Value is already set when identical */
			else if ((fd >= 0 ? sys_fsetxattr(fd, name, ptr, len)
					  : sys_lsetxattr(fname, name, ptr, len)) < 0) {
				rsyserr(FERROR_XFER, errno,
					"rsync_xal_set: %ssetxattr(%s,\"%s\") failed",
					fd >= 0 ? "f" : "l", full_fname(fname), name);
				ret = -1;
			} else /* make sure caller sets mtime */
				sxp->st.st_mtime = (time_t)-1;

			if (am_generator) { /* generator items stay abbreviated */
				free(ptr);
				continue;
			}

			memcpy(ptr + len, name, name_len);
			free(rxas[i].datum);

			rxas[i].name = ptr + len;
			rxas[i].datum = ptr;
			continue;
		}

		if ((fd >= 0 ? sys_fsetxattr(fd, name, rxas[i].datum, rxas[i].datum_len)
			     : sys_lsetxattr(fname, name, rxas[i].datum, rxas[i].datum_len)) < 0) {
			rsyserr(FERROR_XFER, errno,
				"rsync_xal_set: %ssetxattr(%s,\"%s\") failed",
				fd >= 0 ? "f" : "l", full_fname(fname), name);
			ret = -1;
		} else /* make sure caller sets mtime */
			sxp->st.st_mtime = (time_t)-1;
	}

	/* Remove any extraneous names. */
	for (name = namebuf; list_len > 0; name += name_len) {
		name_len = strlen(name) + 1;
		list_len -= name_len;

		if (saw_xattr_filter) {
			if (name_is_excluded(name, NAME_IS_XATTR, ALL_FILTERS))
				continue;
		}
#ifdef HAVE_LINUX_XATTRS
		/* Choose between ignoring the system namespace or (non-root) ignoring any non-user namespace. */
		else if (user_only ? !HAS_PREFIX(name, USER_PREFIX) : HAS_PREFIX(name, SYSTEM_PREFIX))
			continue;
#endif
		if (am_root < 0 && name_len > RPRE_LEN && name[RPRE_LEN] == '%' && strcmp(name, XSTAT_ATTR) == 0)
			continue;

		for (i = 0; i < xalp->count; i++) {
			if (strcmp(name, rxas[i].name) == 0)
				break;
		}
		if (i == xalp->count) {
			if ((fd >= 0 ? sys_fremovexattr(fd, name)
				     : sys_lremovexattr(fname, name)) < 0) {
				rsyserr(FERROR_XFER, errno,
					"rsync_xal_set: %sremovexattr(%s,\"%s\") failed",
					fd >= 0 ? "f" : "l", full_fname(fname), name);
				ret = -1;
			} else /* make sure caller sets mtime */
				sxp->st.st_mtime = (time_t)-1;
		}
	}

	return ret;
}

/* Set extended attributes on indicated filename.  When fd >= 0 it is a held,
 * O_NOFOLLOW-opened fd for fname (a regular file or directory) and the xattr
 * ops go through it (fsetxattr/fremovexattr/flistxattr) so a parent-symlink
 * race can't redirect them; fd < 0 keeps the path-based behavior (symlinks,
 * special files, non-hardened receivers, platforms without the f-variants). */
int set_xattr(const char *fname, const struct file_struct *file, const char *fnamecmp, stat_x *sxp, int fd)
{
	rsync_xa_list *glst = rsync_xal_l.items;
	item_list *lst;
	int ndx, added_write_perm = 0;

	if (dry_run)
		return 1; /* FIXME: --dry-run needs to compute this value */

	if (read_only || list_only) {
		errno = EROFS;
		return -1;
	}

#ifdef NO_SPECIAL_XATTRS
	if (IS_SPECIAL(sxp->st.st_mode)) {
		errno = ENOTSUP;
		return -1;
	}
#endif
#ifdef NO_DEVICE_XATTRS
	if (IS_DEVICE(sxp->st.st_mode)) {
		errno = ENOTSUP;
		return -1;
	}
#endif
#ifdef NO_SYMLINK_XATTRS
	if (S_ISLNK(sxp->st.st_mode)) {
		errno = ENOTSUP;
		return -1;
	}
#endif

	/* If the target file lacks write permission, we try to add it
	 * temporarily so we can change the extended attributes.  With a held fd
	 * the perm change goes through fchmod() on the pinned inode rather than
	 * re-resolving the path. */
	if (!am_root
#ifdef SUPPORT_LINKS
	 && !S_ISLNK(sxp->st.st_mode)
#endif
	 && access(fname, W_OK) < 0
	 && (fd >= 0 ? fchmod(fd, (sxp->st.st_mode & CHMOD_BITS) | S_IWUSR)
		     : do_chmod_at(fname, (sxp->st.st_mode & CHMOD_BITS) | S_IWUSR)) == 0)
		added_write_perm = 1;

	ndx = F_XATTR(file);
	if (ndx < 0) {
		/* No cached xattr list for this file (e.g. the cache_tmp_xattr()
		 * path on --backup); match the guards at the other F_XATTR()
		 * consumers rather than indexing rsync_xal_l.items[-1]. */
		if (added_write_perm) {
			if (fd >= 0)
				fchmod(fd, sxp->st.st_mode);
			else
				do_chmod_at(fname, sxp->st.st_mode);
		}
		return 0;
	}
	glst += ndx;
	lst = &glst->xa_items;
	int return_value = rsync_xal_set(fname, lst, fnamecmp, sxp, fd);
	if (added_write_perm) { /* remove the temporary write permission */
		if (fd >= 0)
			fchmod(fd, sxp->st.st_mode);
		else
			do_chmod_at(fname, sxp->st.st_mode);
	}
	return return_value;
}

#ifdef SUPPORT_ACLS
char *get_xattr_acl(const char *fname, int fd, int is_access_acl, size_t *len_p)
{
	const char *name = is_access_acl ? XACC_ACL_ATTR : XDEF_ACL_ATTR;
	*len_p = 0; /* no extra data alloc needed from get_xattr_data() */
	return get_xattr_data(fname, fd, name, len_p, 1);
}

/* Store/delete a --fake-super ACL-as-xattr.  When fd >= 0 (a held O_NOFOLLOW fd
 * from set_file_attrs) use the f-variant so a parent-symlink race can't redirect
 * the write; otherwise fall back to the l-variant on the path. */
int set_xattr_acl(int fd, const char *fname, int is_access_acl, const char *buf, size_t buf_len)
{
	const char *name = is_access_acl ? XACC_ACL_ATTR : XDEF_ACL_ATTR;
	if ((fd >= 0 ? sys_fsetxattr(fd, name, buf, buf_len)
		     : sys_lsetxattr(fname, name, buf, buf_len)) < 0) {
		rsyserr(FERROR_XFER, errno,
			"set_xattr_acl: %ssetxattr(%s,\"%s\") failed",
			fd >= 0 ? "f" : "l", full_fname(fname), name);
		return -1;
	}
	return 0;
}

int del_def_xattr_acl(int fd, const char *fname)
{
	return fd >= 0 ? sys_fremovexattr(fd, XDEF_ACL_ATTR)
		       : sys_lremovexattr(fname, XDEF_ACL_ATTR);
}
#endif

int get_stat_xattr(const char *fname, int fd, STRUCT_STAT *fst, STRUCT_STAT *xst)
{
	unsigned int mode;
	int rdev_major, rdev_minor, uid, gid, len;
	char buf[256];

	if (am_root >= 0 || IS_DEVICE(fst->st_mode) || IS_SPECIAL(fst->st_mode))
		return -1;

	if (xst)
		*xst = *fst;
	else
		xst = fst;
	if (fname) {
		len = sys_lgetxattr(fname, XSTAT_ATTR, buf, sizeof buf - 1);
	} else {
		fname = "fd";
		len = sys_fgetxattr(fd, XSTAT_ATTR, buf, sizeof buf - 1);
	}
	if (len >= (int)sizeof buf) {
		len = -1;
		errno = ERANGE;
	}
	if (len < 0) {
		if (errno == ENOTSUP || errno == ENOATTR)
			return -1;
		if (errno == EPERM && S_ISLNK(fst->st_mode)) {
			xst->st_uid = 0;
			xst->st_gid = 0;
			return 0;
		}
		rsyserr(FERROR_XFER, errno, "failed to read xattr %s for %s",
			XSTAT_ATTR, full_fname(fname));
		return -1;
	}
	buf[len] = '\0';

	if (sscanf(buf, "%o %d,%d %d:%d",
		   &mode, &rdev_major, &rdev_minor, &uid, &gid) != 5) {
		rprintf(FERROR, "Corrupt %s xattr attached to %s: \"%s\"\n",
			XSTAT_ATTR, full_fname(fname), buf);
		exit_cleanup(RERR_FILEIO);
	}

	xst->st_mode = from_wire_mode(mode);
	xst->st_rdev = MAKEDEV(rdev_major, rdev_minor);
	xst->st_uid = uid;
	xst->st_gid = gid;

	return 0;
}

/* Store the fake-super %stat metadata on fname.  When fd >= 0 it is a held,
 * O_NOFOLLOW-opened fd for fname (regular file or directory): the re-stat, the
 * permission reset and the xattr write/remove go through it so a parent-symlink
 * race can't redirect them.  fd < 0 keeps the path-based behavior (symlinks,
 * devices/specials, non-hardened receivers, platforms without the f-variants). */
int set_stat_xattr(const char *fname, struct file_struct *file, mode_t new_mode, int fd)
{
	STRUCT_STAT fst, xst;
	dev_t rdev;
	mode_t mode, fmode;

	if (dry_run)
		return 0;

	if (read_only || list_only) {
		rsyserr(FERROR_XFER, EROFS, "failed to write xattr %s for %s",
			XSTAT_ATTR, full_fname(fname));
		return -1;
	}

	if (fd >= 0) {
		if (do_fstat(fd, &fst) < 0) {
			rsyserr(FERROR_XFER, errno, "failed to re-stat %s",
				full_fname(fname));
			return -1;
		}
		if (get_stat_xattr(NULL, fd, &fst, &xst) < 0) {
			xst = fst; /* keep xst fully defined; st_mode=0 means "no stat xattr" */
			xst.st_mode = 0;
		}
	} else if (x_lstat(fname, &fst, &xst) < 0) {
		rsyserr(FERROR_XFER, errno, "failed to re-stat %s",
			full_fname(fname));
		return -1;
	}

	fst.st_mode &= (_S_IFMT | CHMOD_BITS);
	fmode = new_mode & (_S_IFMT | CHMOD_BITS);

	if (IS_DEVICE(fmode)) {
		uint32 *devp = F_RDEV_P(file);
		rdev = MAKEDEV(DEV_MAJOR(devp), DEV_MINOR(devp));
	} else
		rdev = 0;

	/* Dump the special permissions and enable full owner access. */
	mode = (fst.st_mode & _S_IFMT) | (fmode & ACCESSPERMS)
	     | (S_ISDIR(fst.st_mode) ? 0700 : 0600);
	if (fst.st_mode != mode) {
		if (fd >= 0)
			fchmod(fd, mode);
		else
			do_chmod_at(fname, mode);
	}
	if (!IS_DEVICE(fst.st_mode))
		fst.st_rdev = 0; /* just in case */

	if (mode == fmode && fst.st_rdev == rdev
	 && fst.st_uid == F_OWNER(file) && fst.st_gid == F_GROUP(file)) {
		/* xst.st_mode will be 0 if there's no current stat xattr */
		if (xst.st_mode && (fd >= 0 ? sys_fremovexattr(fd, XSTAT_ATTR)
					    : sys_lremovexattr(fname, XSTAT_ATTR)) < 0) {
			rsyserr(FERROR_XFER, errno,
				"delete of stat xattr failed for %s",
				full_fname(fname));
			return -1;
		}
		return 0;
	}

	if (xst.st_mode != fmode || xst.st_rdev != rdev
	 || xst.st_uid != F_OWNER(file) || xst.st_gid != F_GROUP(file)) {
		char buf[256];
		int len = snprintf(buf, sizeof buf, "%o %u,%u %u:%u",
			to_wire_mode(fmode),
			(int)major(rdev), (int)minor(rdev),
			F_OWNER(file), F_GROUP(file));
		if ((fd >= 0 ? sys_fsetxattr(fd, XSTAT_ATTR, buf, len)
			     : sys_lsetxattr(fname, XSTAT_ATTR, buf, len)) < 0) {
			if (errno == EPERM && S_ISLNK(fst.st_mode))
				return 0;
			rsyserr(FERROR_XFER, errno,
				"failed to write xattr %s for %s",
				XSTAT_ATTR, full_fname(fname));
			return -1;
		}
	}

	return 0;
}

int x_stat(const char *fname, STRUCT_STAT *fst, STRUCT_STAT *xst)
{
	/* Use the *_at variants so that on a daemon-no-chroot deployment
	 * the metadata read goes through a secure parent dirfd instead
	 * of bare path resolution. The *_at wrappers fall through to
	 * plain do_stat outside the daemon-no-chroot context, so this
	 * change is transparent for non-daemon use. */
	int ret = do_stat_at(fname, fst);
	if ((ret < 0 || get_stat_xattr(fname, -1, fst, xst) < 0) && xst)
		xst->st_mode = 0;
	return ret;
}

int x_lstat(const char *fname, STRUCT_STAT *fst, STRUCT_STAT *xst)
{
	int ret = do_lstat_at(fname, fst);
	if ((ret < 0 || get_stat_xattr(fname, -1, fst, xst) < 0) && xst)
		xst->st_mode = 0;
	return ret;
}

int x_fstat(int fd, STRUCT_STAT *fst, STRUCT_STAT *xst)
{
	int ret = do_fstat(fd, fst);
	if ((ret < 0 || get_stat_xattr(NULL, fd, fst, xst) < 0) && xst)
		xst->st_mode = 0;
	return ret;
}

#endif /* SUPPORT_XATTRS */
