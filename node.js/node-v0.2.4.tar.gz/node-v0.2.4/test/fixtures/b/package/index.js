exports.hello = "world";
common.debug("load package/index.js");
