(function() {
  require('util').print('Loaded successfully!');
})();