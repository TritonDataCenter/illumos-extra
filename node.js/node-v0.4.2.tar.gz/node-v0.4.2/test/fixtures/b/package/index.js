exports.hello = 'world';
console.error('load package/index.js');
