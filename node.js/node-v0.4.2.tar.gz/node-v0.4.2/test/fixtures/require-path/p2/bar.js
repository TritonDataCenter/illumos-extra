
exports.INBAR = __filename;
