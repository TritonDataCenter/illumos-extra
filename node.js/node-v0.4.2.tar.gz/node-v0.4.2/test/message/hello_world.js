var common = require('../common');
var assert = require('assert');

console.log('hello world');
