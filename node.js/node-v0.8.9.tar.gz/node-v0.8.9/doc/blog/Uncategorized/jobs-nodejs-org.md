title: jobs.nodejs.org
author: ryandahl
date: Thu Mar 24 2011 23:05:22 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: jobs-nodejs-org

We are starting an official jobs board for Node. There are two goals for this

1. Promote the small emerging economy around this platform by having a central space for employers to find Node programmers.

2. Make some money. We work hard to build this platform and taking a small tax for job posts seems a like reasonable "tip jar".

<a href="http://jobs.nodejs.org">jobs.nodejs.org</a>
