title: Welcome to the Node blog
author: ryandahl
date: Thu Mar 17 2011 20:17:12 GMT-0700 (PDT)
status: publish
category: video
slug: welcome-to-the-node-blog

Since Livejournal is disintegrating into Russian spam, I'm moving my technical blog to http://blog.nodejs.org/. I hope to do frequent small posts about what's going on in Node development and include posts from other core Node developers. Please subscribe to the RSS feed.

To avoid making this post completely devoid of content, here is a new video from a talk I gave at the SF PHP group tastefully produced by <A href="http://marakana.com/forums/java/general/278.html">Marakana</a>:
<iframe width="640" height="360"
src="http://www.youtube.com/embed/jo_B4LTHi3I" frameborder="0"
allowfullscreen></iframe>
