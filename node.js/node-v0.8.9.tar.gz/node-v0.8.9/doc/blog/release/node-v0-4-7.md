version: 0.4.7
title: Node v0.4.7
author: ryandahl
date: Sat Apr 23 2011 00:47:55 GMT-0700 (PDT)
status: publish
category: release
slug: node-v0-4-7

2011.04.22, Version 0.4.7 (stable)
<ul><li> Don't emit error on ECONNRESET from read() #670
<li> Fix: Multiple pipes to the same stream were broken #929 (Felix Geisendörfer)
<li> URL parsing/formatting corrections #954 (isaacs)
<li> make it possible to do repl.start('', stream) (Wade Simmons)
<li> Add os.loadavg for SunOS (Robert Mustacchi)
<li> Fix timeouts with floating point numbers #897  (Jorge Chamorro Bieling)
<li> Improve docs.</ul>


Download: <a href="http://nodejs.org/dist/node-v0.4.7.tar.gz">http://nodejs.org/dist/node-v0.4.7.tar.gz</a>

Website: <a href="http://nodejs.org/docs/v0.4.7/">http://nodejs.org/docs/v0.4.7/</a>

Documentation: <a href="http://nodejs.org/docs/v0.4.7/api">http://nodejs.org/docs/v0.4.7/api</a>
