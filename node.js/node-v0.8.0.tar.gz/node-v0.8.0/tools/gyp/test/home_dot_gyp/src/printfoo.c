#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("FOO is %s\n", FOO);
  return 0;
}
