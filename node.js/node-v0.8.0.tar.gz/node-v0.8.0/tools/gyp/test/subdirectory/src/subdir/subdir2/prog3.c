#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello from prog3.c\n");
  return 0;
}
