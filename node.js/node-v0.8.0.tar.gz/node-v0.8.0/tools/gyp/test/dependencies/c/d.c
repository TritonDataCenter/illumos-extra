int funcD() {
  return 4;
}
