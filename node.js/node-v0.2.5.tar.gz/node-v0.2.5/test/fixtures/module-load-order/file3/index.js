exports.file3 = 'file3/index.js';
