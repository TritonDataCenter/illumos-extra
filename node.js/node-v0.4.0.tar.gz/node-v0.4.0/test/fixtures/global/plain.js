foo = 'foo';
global.bar = 'bar';

exports.fooBar = {foo: global.foo, bar: bar};
